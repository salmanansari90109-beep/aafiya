import { motion } from 'motion/react';

export default function About() {
  return (
    <div className="pb-24">
      {/* Hero */}
      <section className="relative h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=2000" 
            alt="About AFIA" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-brand-dark/40" />
        </div>
        <div className="relative text-center text-white px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <span className="uppercase tracking-[0.4em] text-xs font-bold mb-4 block">Our Story</span>
            <h1 className="text-5xl md:text-7xl font-serif">AFIA Stylist Collection</h1>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="space-y-12 text-center">
          <h2 className="text-4xl font-serif italic text-brand-gold">"Fashion is the armor to survive the reality of everyday life."</h2>
          
          <div className="space-y-6 text-brand-dark/70 leading-relaxed text-lg text-left">
            <p>
              AFIA Stylist Collection was born from a passion for traditional Pakistani craftsmanship and a vision to bring high-quality, elegant fashion to women everywhere. Founded by **MD Bhai YT**, our brand stands for authenticity, quality, and timeless style.
            </p>
            <p>
              We specialize in curated Pakistani Kurtis, designer bags, and traditional outfits that blend cultural heritage with modern silhouettes. Each piece in our collection is selected with meticulous attention to detail, ensuring that our customers feel confident and beautiful in every thread they wear.
            </p>
            <p>
              Our mission is to empower women through fashion that tells a story. Whether it's a hand-embroidered silk kurti for a festive occasion or a sophisticated leather tote for everyday elegance, AFIA Stylist Collection is your destination for premium fashion.
            </p>
          </div>

          <div className="pt-12 grid grid-cols-1 md:grid-cols-3 gap-12">
            <div>
              <h4 className="text-4xl font-serif text-brand-gold mb-2">100%</h4>
              <p className="text-xs uppercase tracking-widest font-bold">Authentic Designs</p>
            </div>
            <div>
              <h4 className="text-4xl font-serif text-brand-gold mb-2">5000+</h4>
              <p className="text-xs uppercase tracking-widest font-bold">Happy Customers</p>
            </div>
            <div>
              <h4 className="text-4xl font-serif text-brand-gold mb-2">Nepal</h4>
              <p className="text-xs uppercase tracking-widest font-bold">Based in Kathmandu</p>
            </div>
          </div>
        </div>
      </section>

      {/* Founder Section */}
      <section className="bg-brand-blush/20 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center gap-16">
            <div className="w-full md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=800" 
                alt="MD Bhai YT" 
                className="w-full h-[500px] object-cover rounded-none grayscale hover:grayscale-0 transition-all duration-700"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="w-full md:w-1/2 space-y-6">
              <span className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold block">The Visionary</span>
              <h2 className="text-4xl font-serif">MD Bhai YT</h2>
              <p className="text-brand-dark/60 italic">Founder & Creative Director</p>
              <p className="text-brand-dark/70 leading-relaxed">
                "I started AFIA Stylist Collection with a simple goal: to make premium traditional fashion accessible without compromising on quality. My journey in the fashion world has always been driven by the smiles of our customers when they find that perfect outfit."
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
