import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent } from '../components/ui/card';
import { motion } from 'motion/react';

export default function Contact() {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, send to backend
    alert('Thank you for your message! We will get back to you soon.');
    setFormState({ name: '', email: '', message: '' });
  };

  return (
    <div className="pb-24">
      {/* Header */}
      <section className="bg-brand-blush/30 py-24 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <span className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-4 block">Get In Touch</span>
            <h1 className="text-5xl font-serif mb-6">Contact Us</h1>
            <p className="text-brand-dark/60 max-w-2xl mx-auto">
              Have questions about our collection or need help with an order? We're here to assist you.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Contact Info */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="border-none shadow-sm bg-white rounded-none p-8">
              <CardContent className="p-0 space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-brand-blush p-3 rounded-full">
                    <Phone className="h-6 w-6 text-brand-gold" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm uppercase tracking-widest mb-1">Phone</h4>
                    <p className="text-brand-dark/60">+977 9819823380</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-brand-blush p-3 rounded-full">
                    <Mail className="h-6 w-6 text-brand-gold" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm uppercase tracking-widest mb-1">Email</h4>
                    <p className="text-brand-dark/60">info@afiastylist.com</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-brand-blush p-3 rounded-full">
                    <MapPin className="h-6 w-6 text-brand-gold" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm uppercase tracking-widest mb-1">Location</h4>
                    <p className="text-brand-dark/60">Kathmandu, Nepal</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-sm bg-brand-dark text-white rounded-none p-8">
              <CardContent className="p-0">
                <h4 className="font-serif text-2xl mb-4">Store Hours</h4>
                <ul className="space-y-2 text-white/70 text-sm">
                  <li className="flex justify-between"><span>Mon - Fri:</span> <span>10:00 AM - 8:00 PM</span></li>
                  <li className="flex justify-between"><span>Saturday:</span> <span>11:00 AM - 6:00 PM</span></li>
                  <li className="flex justify-between"><span>Sunday:</span> <span>Closed</span></li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card className="border-none shadow-sm bg-white rounded-none p-8 sm:p-12">
              <CardContent className="p-0">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest">Full Name</label>
                      <Input 
                        required
                        className="rounded-none border-brand-blush focus:border-brand-gold h-12"
                        value={formState.name}
                        onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest">Email Address</label>
                      <Input 
                        required
                        type="email"
                        className="rounded-none border-brand-blush focus:border-brand-gold h-12"
                        value={formState.email}
                        onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest">Message</label>
                    <textarea 
                      required
                      rows={6}
                      className="w-full rounded-none border border-brand-blush focus:border-brand-gold p-4 outline-none transition-colors"
                      value={formState.message}
                      onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                    />
                  </div>
                  <Button type="submit" className="bg-brand-gold hover:bg-brand-gold/90 text-white px-10 h-14 rounded-none uppercase tracking-widest text-xs w-full sm:w-auto">
                    <Send className="h-4 w-4 mr-2" />
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
