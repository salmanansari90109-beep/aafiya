import { useParams, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { Button } from '../components/ui/button';
import { useCart } from '../lib/CartContext';
import { ShoppingBag, Heart, Share2, ChevronRight, ChevronLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedSize, setSelectedSize] = useState('M');
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const docRef = doc(db, 'products', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setProduct({ id: docSnap.id, ...docSnap.data() });
        } else {
          // Mock fallback
          setProduct({
            id: id,
            name: 'Embroidered Silk Kurti',
            price: 4500,
            description: 'This exquisite silk kurti features intricate hand embroidery on the neckline and sleeves. Perfect for festive occasions and formal gatherings. The soft silk fabric ensures comfort while maintaining a luxurious look.',
            images: [
              'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800',
              'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=800'
            ],
            category: 'Kurtis',
            sizes: ['S', 'M', 'L', 'XL'],
            details: [
              'Fabric: Premium Silk',
              'Embroidery: Hand-done thread work',
              'Fit: Regular Fit',
              'Care: Dry Clean Only'
            ]
          });
        }
      } catch (error) {
        console.error("Error fetching product:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  if (loading) return <div className="h-screen flex items-center justify-center">Loading...</div>;
  if (!product) return <div className="h-screen flex items-center justify-center">Product not found</div>;

  return (
    <div className="pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="relative aspect-[3/4] overflow-hidden bg-brand-blush/10">
              <AnimatePresence mode="wait">
                <motion.img
                  key={activeImage}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  src={product.images[activeImage]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </AnimatePresence>
              
              {product.images.length > 1 && (
                <div className="absolute inset-0 flex items-center justify-between px-4">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="bg-white/50 hover:bg-white rounded-full"
                    onClick={() => setActiveImage((prev) => (prev === 0 ? product.images.length - 1 : prev - 1))}
                  >
                    <ChevronLeft className="h-6 w-6" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="bg-white/50 hover:bg-white rounded-full"
                    onClick={() => setActiveImage((prev) => (prev === product.images.length - 1 ? 0 : prev + 1))}
                  >
                    <ChevronRight className="h-6 w-6" />
                  </Button>
                </div>
              )}
            </div>
            
            <div className="flex gap-4 overflow-x-auto pb-2">
              {product.images.map((img: string, i: number) => (
                <button
                  key={i}
                  onClick={() => setActiveImage(i)}
                  className={`relative w-24 aspect-[3/4] overflow-hidden border-2 transition-colors ${
                    activeImage === i ? 'border-brand-gold' : 'border-transparent'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-8">
            <div>
              <p className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-2">{product.category}</p>
              <h1 className="text-4xl md:text-5xl font-serif mb-4">{product.name}</h1>
              <p className="text-2xl text-brand-dark/80">Rs. {product.price.toLocaleString()}</p>
            </div>

            <p className="text-brand-dark/60 leading-relaxed">
              {product.description}
            </p>

            {/* Size Selection */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label className="text-xs font-bold uppercase tracking-widest">Select Size</label>
                <button className="text-[10px] uppercase tracking-widest text-brand-gold border-b border-brand-gold">Size Guide</button>
              </div>
              <div className="flex flex-wrap gap-3">
                {(product.sizes || ['S', 'M', 'L', 'XL']).map((size: string) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`w-12 h-12 flex items-center justify-center text-sm border transition-all ${
                      selectedSize === size 
                        ? 'bg-brand-dark text-white border-brand-dark' 
                        : 'border-brand-blush hover:border-brand-gold'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button 
                className="flex-1 bg-brand-gold hover:bg-brand-gold/90 text-white h-14 rounded-none uppercase tracking-widest text-xs"
                onClick={() => {
                  addToCart({
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    image: product.images[0],
                    quantity: 1,
                    size: selectedSize
                  });
                  navigate('/cart');
                }}
              >
                <ShoppingBag className="h-4 w-4 mr-2" />
                Add to Bag
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" className="h-14 w-14 rounded-none border-brand-blush hover:border-brand-gold">
                  <Heart className="h-5 w-5" />
                </Button>
                <Button variant="outline" className="h-14 w-14 rounded-none border-brand-blush hover:border-brand-gold">
                  <Share2 className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Details Accordion (Simplified) */}
            <div className="border-t border-brand-blush pt-8 space-y-6">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-widest mb-4">Product Details</h4>
                <ul className="space-y-2">
                  {(product.details || []).map((detail: string, i: number) => (
                    <li key={i} className="text-sm text-brand-dark/60 flex items-center">
                      <span className="w-1.5 h-1.5 bg-brand-gold rounded-full mr-3" />
                      {detail}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="grid grid-cols-2 gap-8 pt-4">
                <div className="space-y-2">
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-brand-dark/40">Shipping</h4>
                  <p className="text-xs text-brand-dark/60">Free shipping on orders over Rs. 5000</p>
                </div>
                <div className="space-y-2">
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-brand-dark/40">Returns</h4>
                  <p className="text-xs text-brand-dark/60">Easy 7-day returns and exchanges</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
