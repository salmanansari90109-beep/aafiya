import { useEffect, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { db, auth } from '../firebase';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { LogOut, Package, User as UserIcon, Settings } from 'lucide-react';
import { motion } from 'motion/react';

export default function Account() {
  const { user, profile, loading: authLoading } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const fetchOrders = async () => {
      if (!user) return;
      try {
        const q = query(
          collection(db, 'orders'),
          where('userId', '==', user.uid),
          orderBy('createdAt', 'desc')
        );
        const querySnapshot = await getDocs(q);
        setOrders(querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (error) {
        console.error("Error fetching orders:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [user]);

  const handleLogout = async () => {
    await auth.signOut();
    navigate('/');
  };

  if (authLoading || !user) return <div className="h-screen flex items-center justify-center">Loading...</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-serif mb-2">My Account</h1>
          <p className="text-brand-dark/60">Welcome back, {profile?.displayName || user.email}</p>
        </div>
        <Button 
          variant="outline" 
          className="rounded-none border-brand-blush hover:border-red-200 hover:text-red-500"
          onClick={handleLogout}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Logout
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          <Card className="border-none shadow-sm rounded-none bg-white">
            <CardContent className="p-4 space-y-2">
              <Button variant="ghost" className="w-full justify-start rounded-none bg-brand-blush/30 text-brand-gold">
                <Package className="h-4 w-4 mr-3" />
                My Orders
              </Button>
              <Button variant="ghost" className="w-full justify-start rounded-none text-brand-dark/60">
                <UserIcon className="h-4 w-4 mr-3" />
                Profile Info
              </Button>
              <Button variant="ghost" className="w-full justify-start rounded-none text-brand-dark/60">
                <Settings className="h-4 w-4 mr-3" />
                Account Settings
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3 space-y-8">
          <section>
            <h2 className="text-xl font-serif mb-6">Recent Orders</h2>
            {loading ? (
              <div className="space-y-4">
                {[1, 2].map(i => <div key={i} className="h-32 bg-brand-blush/10 animate-pulse" />)}
              </div>
            ) : orders.length === 0 ? (
              <Card className="border-none shadow-sm rounded-none bg-white p-12 text-center">
                <CardContent className="p-0">
                  <Package className="h-12 w-12 text-brand-blush mx-auto mb-4" />
                  <p className="text-brand-dark/60 mb-6">You haven't placed any orders yet.</p>
                  <Button 
                    className="bg-brand-dark text-white rounded-none uppercase tracking-widest text-xs"
                    onClick={() => navigate('/shop')}
                  >
                    Start Shopping
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                {orders.map((order) => (
                  <Card key={order.id} className="border-none shadow-sm rounded-none bg-white overflow-hidden">
                    <CardHeader className="bg-brand-blush/10 border-b border-brand-blush/20 py-4 px-6">
                      <div className="flex flex-wrap justify-between items-center gap-4">
                        <div className="flex gap-8">
                          <div>
                            <p className="text-[10px] uppercase tracking-widest text-brand-dark/40 mb-1">Order Date</p>
                            <p className="text-sm font-medium">{new Date(order.createdAt).toLocaleDateString()}</p>
                          </div>
                          <div>
                            <p className="text-[10px] uppercase tracking-widest text-brand-dark/40 mb-1">Total Amount</p>
                            <p className="text-sm font-medium">Rs. {order.totalAmount.toLocaleString()}</p>
                          </div>
                        </div>
                        <Badge className={`rounded-none uppercase text-[10px] tracking-widest px-3 py-1 ${
                          order.status === 'delivered' ? 'bg-green-100 text-green-700' : 'bg-brand-gold/10 text-brand-gold'
                        }`}>
                          {order.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {order.items.map((item: any, i: number) => (
                          <div key={i} className="flex items-center gap-4">
                            <img src={item.image} alt={item.name} className="w-12 h-16 object-cover" />
                            <div className="flex-1">
                              <p className="text-sm font-medium">{item.name}</p>
                              <p className="text-xs text-brand-dark/40">Size: {item.size} | Qty: {item.quantity}</p>
                            </div>
                            <p className="text-sm font-medium">Rs. {(item.price * item.quantity).toLocaleString()}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
