import { Link } from 'react-router-dom';
import { useCart } from '../lib/CartContext';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/button';
import { motion } from 'motion/react';

export default function Cart() {
  const { items, removeFromCart, updateQuantity, total } = useCart();

  if (items.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center px-4">
        <div className="bg-brand-blush/30 p-8 rounded-full mb-8">
          <ShoppingBag className="h-12 w-12 text-brand-gold" />
        </div>
        <h1 className="text-3xl font-serif mb-4">Your bag is empty</h1>
        <p className="text-brand-dark/60 mb-8 text-center max-w-md">
          Looks like you haven't added any items to your bag yet. Start exploring our collection to find your perfect style.
        </p>
        <Link to="/shop">
          <Button className="bg-brand-dark text-white px-10 h-14 rounded-none uppercase tracking-widest text-xs">
            Start Shopping
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <h1 className="text-4xl font-serif mb-12">Shopping Bag</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-8">
          {items.map((item) => (
            <motion.div 
              key={`${item.id}-${item.size}`}
              layout
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-6 pb-8 border-b border-brand-blush/30"
            >
              <div className="w-24 sm:w-32 aspect-[3/4] overflow-hidden bg-brand-blush/10 flex-shrink-0">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              
              <div className="flex-1 flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-serif mb-1">{item.name}</h3>
                    <p className="text-xs text-brand-dark/40 uppercase tracking-widest mb-2">Size: {item.size}</p>
                    <p className="text-brand-gold font-medium">Rs. {item.price.toLocaleString()}</p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-brand-dark/40 hover:text-red-500"
                    onClick={() => removeFromCart(item.id, item.size)}
                  >
                    <Trash2 className="h-5 w-5" />
                  </Button>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex items-center border border-brand-blush">
                    <button 
                      className="p-2 hover:bg-brand-blush/30 transition-colors"
                      onClick={() => updateQuantity(item.id, item.size, item.quantity - 1)}
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="w-10 text-center text-sm font-medium">{item.quantity}</span>
                    <button 
                      className="p-2 hover:bg-brand-blush/30 transition-colors"
                      onClick={() => updateQuantity(item.id, item.size, item.quantity + 1)}
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                  <p className="text-sm font-bold">Total: Rs. {(item.price * item.quantity).toLocaleString()}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white p-8 border border-brand-blush/30 sticky top-32">
            <h2 className="text-xl font-serif mb-8">Order Summary</h2>
            
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-sm">
                <span className="text-brand-dark/60">Subtotal</span>
                <span>Rs. {total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-brand-dark/60">Shipping</span>
                <span className="text-green-600">Free</span>
              </div>
              <div className="border-t border-brand-blush pt-4 flex justify-between font-bold text-lg">
                <span>Total</span>
                <span className="text-brand-gold">Rs. {total.toLocaleString()}</span>
              </div>
            </div>

            <Link to="/checkout">
              <Button className="w-full bg-brand-dark hover:bg-brand-dark/90 text-white h-14 rounded-none uppercase tracking-widest text-xs">
                Proceed to Checkout
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </Link>

            <div className="mt-8 space-y-4">
              <p className="text-[10px] uppercase tracking-widest text-brand-dark/40 text-center">Secure Checkout Guaranteed</p>
              <div className="flex justify-center gap-4 opacity-40">
                <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="PayPal" className="h-4" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" alt="Visa" className="h-3" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="Mastercard" className="h-4" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
