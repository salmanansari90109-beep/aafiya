import { motion } from 'motion/react';
import { Card, CardContent } from '../components/ui/card';
import { Link } from 'react-router-dom';

const BLOG_POSTS = [
  {
    id: '1',
    title: 'How to Style Your Kurti for Any Occasion',
    excerpt: 'From casual outings to formal events, learn the art of styling your favorite kurtis with the right accessories.',
    date: 'Oct 12, 2024',
    author: 'AFIA Editorial',
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=800'
  },
  {
    id: '2',
    title: 'Choosing the Perfect Bag for Your Outfit',
    excerpt: 'A bag is more than just an accessory; it\'s a statement. Discover how to match your tote or clutch with your traditional wear.',
    date: 'Oct 08, 2024',
    author: 'MD Bhai YT',
    image: 'https://images.unsplash.com/photo-1584917033904-491a84e2fe01?q=80&w=800'
  },
  {
    id: '3',
    title: 'The Rise of Traditional Fusion Wear',
    excerpt: 'Explore how traditional Pakistani designs are evolving with modern global trends to create unique fusion styles.',
    date: 'Sep 28, 2024',
    author: 'AFIA Editorial',
    image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800'
  },
  {
    id: '4',
    title: 'Fabric Guide: Silk vs Lawn vs Velvet',
    excerpt: 'Understanding your fabrics is key to choosing the right outfit for the right season. Here is our comprehensive guide.',
    date: 'Sep 15, 2024',
    author: 'MD Bhai YT',
    image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=800'
  }
];

export default function Blog() {
  return (
    <div className="pb-24">
      {/* Header */}
      <section className="bg-brand-blush/20 py-24 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <span className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-4 block">Fashion Journal</span>
            <h1 className="text-5xl font-serif mb-6">Style Tips & Trends</h1>
            <p className="text-brand-dark/60 max-w-2xl mx-auto">
              Explore the latest in Pakistani fashion, styling guides, and behind-the-scenes stories from AFIA Stylist Collection.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {BLOG_POSTS.map((post, i) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="border-none shadow-none bg-transparent group cursor-pointer">
                <div className="aspect-video overflow-hidden mb-6">
                  <img 
                    src={post.image} 
                    alt={post.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <CardContent className="p-0 space-y-4">
                  <div className="flex items-center gap-4 text-[10px] uppercase tracking-widest text-brand-gold font-bold">
                    <span>{post.date}</span>
                    <span className="w-1 h-1 bg-brand-gold rounded-full" />
                    <span>By {post.author}</span>
                  </div>
                  <h3 className="text-3xl font-serif group-hover:text-brand-gold transition-colors leading-tight">
                    {post.title}
                  </h3>
                  <p className="text-brand-dark/60 leading-relaxed">
                    {post.excerpt}
                  </p>
                  <Link to={`/blog/${post.id}`} className="inline-block text-xs font-bold uppercase tracking-widest border-b-2 border-brand-gold pb-1 hover:text-brand-gold transition-colors">
                    Read More
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Newsletter */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="bg-brand-dark text-white p-12 md:p-24 text-center space-y-8">
          <h2 className="text-4xl font-serif">Join Our Fashion Community</h2>
          <p className="text-white/60 max-w-lg mx-auto">
            Subscribe to our newsletter and be the first to know about new arrivals, exclusive offers, and style tips.
          </p>
          <form className="max-w-md mx-auto flex flex-col sm:flex-row gap-4">
            <input 
              type="email" 
              placeholder="Your email address" 
              className="flex-1 bg-white/10 border border-white/20 px-6 py-4 outline-none focus:border-brand-gold transition-colors"
            />
            <button className="bg-brand-gold hover:bg-brand-gold/90 text-white px-8 py-4 uppercase tracking-widest text-xs font-bold transition-colors">
              Subscribe
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}
