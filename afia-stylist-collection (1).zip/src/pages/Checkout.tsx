import React, { useState } from 'react';
import { useCart } from '../lib/CartContext';
import { useAuth } from '../lib/AuthContext';
import { db } from '../firebase';
import { collection, addDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent } from '../components/ui/card';
import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

export default function Checkout() {
  const { items, total, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: user?.email || '',
    phone: '',
    address: '',
    city: '',
    country: 'Nepal'
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      navigate('/login');
      return;
    }
    setLoading(true);
    try {
      await addDoc(collection(db, 'orders'), {
        userId: user.uid,
        items,
        totalAmount: total,
        status: 'pending',
        shippingAddress: formData,
        createdAt: new Date().toISOString()
      });
      setIsSuccess(true);
      clearCart();
    } catch (error) {
      console.error("Error creating order:", error);
      alert("Failed to place order. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="bg-green-100 p-6 rounded-full mb-8"
        >
          <CheckCircle2 className="h-16 w-16 text-green-600" />
        </motion.div>
        <h1 className="text-4xl font-serif mb-4">Order Placed Successfully!</h1>
        <p className="text-brand-dark/60 mb-8 max-w-md">
          Thank you for shopping with AFIA Stylist Collection. Your order has been received and is being processed.
        </p>
        <Button 
          className="bg-brand-dark text-white px-10 h-14 rounded-none uppercase tracking-widest text-xs"
          onClick={() => navigate('/account')}
        >
          View My Orders
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <h1 className="text-4xl font-serif mb-12">Checkout</h1>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        {/* Shipping Info */}
        <div className="lg:col-span-2 space-y-12">
          <section>
            <h2 className="text-xl font-serif mb-8 border-b border-brand-blush pb-4">Shipping Information</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest">First Name</label>
                <Input required className="rounded-none" value={formData.firstName} onChange={e => setFormData({...formData, firstName: e.target.value})} />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest">Last Name</label>
                <Input required className="rounded-none" value={formData.lastName} onChange={e => setFormData({...formData, lastName: e.target.value})} />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <label className="text-[10px] font-bold uppercase tracking-widest">Email Address</label>
                <Input required type="email" className="rounded-none" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <label className="text-[10px] font-bold uppercase tracking-widest">Phone Number</label>
                <Input required type="tel" className="rounded-none" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <label className="text-[10px] font-bold uppercase tracking-widest">Street Address</label>
                <Input required className="rounded-none" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest">City</label>
                <Input required className="rounded-none" value={formData.city} onChange={e => setFormData({...formData, city: e.target.value})} />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest">Country</label>
                <Input required disabled className="rounded-none" value={formData.country} />
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-serif mb-8 border-b border-brand-blush pb-4">Payment Method</h2>
            <div className="p-6 border-2 border-brand-gold bg-brand-gold/5 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-4 h-4 rounded-full border-4 border-brand-gold" />
                <span className="font-medium">Cash on Delivery</span>
              </div>
              <p className="text-xs text-brand-dark/60 italic">Pay when you receive your order</p>
            </div>
          </section>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white p-8 border border-brand-blush/30 sticky top-32">
            <h2 className="text-xl font-serif mb-8">Your Order</h2>
            
            <div className="space-y-4 mb-8 max-h-60 overflow-y-auto pr-2">
              {items.map(item => (
                <div key={`${item.id}-${item.size}`} className="flex justify-between text-sm gap-4">
                  <span className="text-brand-dark/60 flex-1">{item.name} (x{item.quantity})</span>
                  <span className="font-medium">Rs. {(item.price * item.quantity).toLocaleString()}</span>
                </div>
              ))}
            </div>

            <div className="space-y-4 mb-8 pt-8 border-t border-brand-blush">
              <div className="flex justify-between text-sm">
                <span className="text-brand-dark/60">Subtotal</span>
                <span>Rs. {total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-brand-dark/60">Shipping</span>
                <span className="text-green-600">Free</span>
              </div>
              <div className="border-t border-brand-blush pt-4 flex justify-between font-bold text-lg">
                <span>Total</span>
                <span className="text-brand-gold">Rs. {total.toLocaleString()}</span>
              </div>
            </div>

            <Button 
              type="submit"
              disabled={loading}
              className="w-full bg-brand-dark hover:bg-brand-dark/90 text-white h-14 rounded-none uppercase tracking-widest text-xs"
            >
              {loading ? 'Processing...' : 'Place Order'}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
