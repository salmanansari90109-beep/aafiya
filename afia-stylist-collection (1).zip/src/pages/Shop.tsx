import { useState, useEffect } from 'react';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '../firebase';
import ProductCard from '../components/ProductCard';
import { Button } from '../components/ui/button';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'motion/react';

// Mock Data for fallback
const MOCK_PRODUCTS = [
  { id: '1', name: 'Embroidered Silk Kurti', price: 4500, images: ['https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800'], category: 'Kurtis' },
  { id: '2', name: 'Designer Leather Tote', price: 3200, images: ['https://images.unsplash.com/photo-1584917033904-491a84e2fe01?q=80&w=800'], category: 'Bags' },
  { id: '3', name: 'Floral Print Lawn Suit', price: 5800, images: ['https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=800'], category: 'Suits' },
  { id: '4', name: 'Handcrafted Clutch', price: 1800, images: ['https://images.unsplash.com/photo-1566150905458-1bf1fd111c36?q=80&w=800'], category: 'Bags' },
  { id: '5', name: 'Velvet Party Kurti', price: 7200, images: ['https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800'], category: 'Kurtis' },
  { id: '6', name: 'Classic Shoulder Bag', price: 2900, images: ['https://images.unsplash.com/photo-1584917033904-491a84e2fe01?q=80&w=800'], category: 'Bags' }
];

export default function Shop() {
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryFilter = searchParams.get('category');
  const [products, setProducts] = useState<any[]>(MOCK_PRODUCTS);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        const q = categoryFilter 
          ? query(collection(db, 'products'), where('category', '==', categoryFilter))
          : collection(db, 'products');
        
        const querySnapshot = await getDocs(q);
        const fetched = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        
        if (fetched.length > 0) {
          setProducts(fetched);
        } else {
          // Fallback to mock if empty
          setProducts(categoryFilter 
            ? MOCK_PRODUCTS.filter(p => p.category.toLowerCase() === categoryFilter.toLowerCase())
            : MOCK_PRODUCTS
          );
        }
      } catch (error) {
        console.error("Error fetching products:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [categoryFilter]);

  const categories = ['All', 'Kurtis', 'Bags', 'Suits', 'Traditional'];

  return (
    <div className="pb-24">
      {/* Header */}
      <section className="bg-brand-blush/20 py-16 border-b border-brand-blush/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-serif mb-4">Shop Collection</h1>
          <div className="flex flex-wrap gap-4">
            {categories.map((cat) => (
              <Button
                key={cat}
                variant={categoryFilter === cat.toLowerCase() || (!categoryFilter && cat === 'All') ? 'default' : 'outline'}
                className={`rounded-none uppercase tracking-widest text-[10px] h-10 px-6 ${
                  categoryFilter === cat.toLowerCase() || (!categoryFilter && cat === 'All')
                    ? 'bg-brand-gold text-white'
                    : 'border-brand-blush text-brand-dark/60 hover:border-brand-gold'
                }`}
                onClick={() => setSearchParams(cat === 'All' ? {} : { category: cat.toLowerCase() })}
              >
                {cat}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Product Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex justify-between items-center mb-8">
          <p className="text-sm text-brand-dark/40">{products.length} Products Found</p>
          <select className="bg-transparent border-none text-sm font-medium uppercase tracking-widest outline-none cursor-pointer text-brand-dark/60">
            <option>Sort By: Newest</option>
            <option>Price: Low to High</option>
            <option>Price: High to Low</option>
          </select>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse space-y-4">
                <div className="aspect-[3/4] bg-brand-blush/20" />
                <div className="h-4 bg-brand-blush/20 w-3/4" />
                <div className="h-4 bg-brand-blush/20 w-1/2" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
