import Hero from '../components/Hero';
import ProductCard from '../components/ProductCard';
import { Button } from '../components/ui/button';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

// Mock Data
const FEATURED_PRODUCTS = [
  {
    id: '1',
    name: 'Embroidered Silk Kurti',
    price: 4500,
    images: ['https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800'],
    category: 'Kurtis',
    isNewArrival: true
  },
  {
    id: '2',
    name: 'Designer Leather Tote',
    price: 3200,
    images: ['https://images.unsplash.com/photo-1584917033904-491a84e2fe01?q=80&w=800'],
    category: 'Bags',
    isBestseller: true
  },
  {
    id: '3',
    name: 'Floral Print Lawn Suit',
    price: 5800,
    images: ['https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=800'],
    category: 'Suits',
    isNewArrival: true
  },
  {
    id: '4',
    name: 'Handcrafted Clutch',
    price: 1800,
    images: ['https://images.unsplash.com/photo-1566150905458-1bf1fd111c36?q=80&w=800'],
    category: 'Bags'
  }
];

export default function Home() {
  return (
    <div className="space-y-24 pb-24">
      <Hero />

      {/* Categories Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { name: 'Kurtis', img: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=800', link: '/shop?category=kurtis' },
            { name: 'Bags', img: 'https://images.unsplash.com/photo-1584917033904-491a84e2fe01?q=80&w=800', link: '/shop?category=bags' },
            { name: 'Traditional', img: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800', link: '/shop?category=traditional' }
          ].map((cat, i) => (
            <motion.div
              key={cat.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className="relative group h-96 overflow-hidden rounded-sleek shadow-sleek"
            >
              <img src={cat.img} alt={cat.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors" />
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                <h3 className="text-3xl font-serif mb-4">{cat.name}</h3>
                <Link to={cat.link}>
                  <Button variant="outline" className="border-white text-white hover:bg-white hover:text-brand-dark rounded-none uppercase tracking-widest text-[10px]">
                    Explore
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* New Arrivals */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-12">
          <div>
            <span className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-2 block">Curated Selection</span>
            <h2 className="text-4xl font-serif">New Arrivals</h2>
          </div>
          <Link to="/shop" className="text-brand-muted hover:text-brand-gold transition-colors text-xs uppercase tracking-widest border-b border-black/10 pb-1">
            View All
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {FEATURED_PRODUCTS.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Brand Story Teaser */}
      <section className="bg-brand-pink/30 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=1000" 
                alt="Brand Story" 
                className="w-full h-[600px] object-cover rounded-sleek shadow-sleek"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-8 -right-8 bg-brand-gold w-48 h-48 rounded-full flex items-center justify-center p-8 text-center shadow-lg">
                <p className="text-white font-serif italic text-lg leading-tight">Crafted with Love by MD Bhai YT</p>
              </div>
            </div>
            <div className="space-y-8">
              <span className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold block">Our Heritage</span>
              <h2 className="text-5xl font-serif leading-tight">AFIA Stylist Collection: A Journey of Style</h2>
              <p className="text-brand-muted leading-relaxed text-lg">
                Founded by MD Bhai YT, AFIA Stylist Collection is more than just a brand. It's a celebration of traditional Pakistani craftsmanship blended with modern aesthetics. Every piece in our collection is handpicked to ensure the highest quality and timeless elegance.
              </p>
              <Link to="/about">
                <Button className="cta-btn rounded-none">
                  Read Our Story
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Blog Teaser */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-4 block">Fashion Journal</span>
          <h2 className="text-4xl font-serif mb-6">Style Tips & Trends</h2>
          <p className="text-brand-dark/60">Stay updated with the latest in Pakistani fashion and styling tips from our experts.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { title: 'How to Style Your Kurti for Any Occasion', date: 'Oct 12, 2024', img: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=800' },
            { title: 'Choosing the Perfect Bag for Your Outfit', date: 'Oct 08, 2024', img: 'https://images.unsplash.com/photo-1584917033904-491a84e2fe01?q=80&w=800' },
            { title: 'The Rise of Traditional Fusion Wear', date: 'Sep 28, 2024', img: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800' }
          ].map((post, i) => (
            <motion.div key={i} className="group cursor-pointer">
              <div className="aspect-video overflow-hidden mb-6">
                <img src={post.img} alt={post.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" referrerPolicy="no-referrer" />
              </div>
              <p className="text-[10px] uppercase tracking-widest text-brand-gold mb-2">{post.date}</p>
              <h3 className="text-xl font-serif group-hover:text-brand-gold transition-colors">{post.title}</h3>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
