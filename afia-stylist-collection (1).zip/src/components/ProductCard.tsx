import { Link } from 'react-router-dom';
import { ShoppingCart, Eye } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter } from './ui/card';
import { Badge } from './ui/badge';
import { useCart } from '../lib/CartContext';
import { motion } from 'motion/react';

interface ProductCardProps {
  key?: string | number;
  product: {
    id: string;
    name: string;
    price: number;
    images: string[];
    category: string;
    isNewArrival?: boolean;
    isBestseller?: boolean;
  };
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();

  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="sleek-card group relative overflow-hidden">
        <div className="img-box aspect-[3/4] overflow-hidden mb-4 relative">
          <Link to={`/product/${product.id}`} className="w-full h-full">
            <img
              src={product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-90 group-hover:opacity-100"
              referrerPolicy="no-referrer"
            />
          </Link>
          
          <div className="absolute top-3 left-3">
            {product.isNewArrival && (
              <div className="badge-sleek">New</div>
            )}
          </div>

          <button 
            className="absolute bottom-4 right-4 w-8 h-8 rounded-full border border-brand-gold flex items-center justify-center text-brand-gold bg-white/80 backdrop-blur-sm hover:bg-brand-gold hover:text-white transition-colors z-10"
            onClick={() => addToCart({
              id: product.id,
              name: product.name,
              price: product.price,
              image: product.images[0],
              quantity: 1,
              size: 'M'
            })}
          >
            +
          </button>
        </div>

        <CardContent className="p-0">
          <h3 className="text-sm font-medium text-brand-dark mb-1 group-hover:text-brand-gold transition-colors truncate">
            {product.name}
          </h3>
          <p className="text-xs font-bold text-brand-gold">Rs. {product.price.toLocaleString()}</p>
        </CardContent>
      </Card>
    </motion.div>
  );
}
