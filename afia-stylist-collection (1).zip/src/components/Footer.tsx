import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-black/5 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap justify-between items-center gap-8">
          <div className="flex flex-col gap-1">
            <span className="text-[10px] uppercase tracking-widest text-brand-muted">Brand Designer</span>
            <span className="text-[13px] font-medium">MD Bhai YT</span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-[10px] uppercase tracking-widest text-brand-muted">Customer Support</span>
            <span className="text-[13px] font-medium">+977 9819823380</span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-[10px] uppercase tracking-widest text-brand-muted">Latest Tip</span>
            <span className="text-[13px] font-medium">"Styling gold accents for festive nights"</span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-[10px] uppercase tracking-widest text-brand-muted">Secure Checkout</span>
            <span className="text-[13px] font-medium">Encrypted SSL Verified</span>
          </div>
        </div>
        <div className="mt-10 pt-8 border-t border-black/5 flex justify-between items-center">
          <p className="text-[10px] text-brand-muted uppercase tracking-widest">
            © 2024 AFIA Stylist Collection. All Rights Reserved.
          </p>
          <div className="flex gap-4 opacity-40 grayscale">
            <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="PayPal" className="h-4" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" alt="Visa" className="h-3" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="Mastercard" className="h-4" />
          </div>
        </div>
      </div>
    </footer>
  );
}
