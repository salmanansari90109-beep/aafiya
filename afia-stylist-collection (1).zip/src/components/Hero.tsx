import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { Button } from './ui/button';

export default function Hero() {
  return (
    <section className="relative h-[80vh] min-h-[600px] overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=2000&auto=format&fit=crop"
          alt="Elegant Fashion"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-black/20" />
      </div>

      {/* Content */}
      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
        <div className="max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="badge-sleek mb-4">Summer 2024</div>
            <span className="inline-block text-brand-gold uppercase tracking-[3px] text-xs font-medium mb-2">
              Elegance in Every Stitch
            </span>
            <h1 className="text-5xl md:text-6xl font-serif text-white leading-[1.1] mb-6">
              Authentic Pakistani Kurtis & Traditional Wear
            </h1>
            <p className="text-white/90 text-[15px] mb-10 max-w-md leading-[1.6]">
              Explore our curated collection of hand-crafted traditional outfits, exquisite bags, and premium textiles designed for the modern woman.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/shop">
                <Button size="lg" className="cta-btn rounded-none">
                  Explore Collection
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/60"
      >
        <div className="w-[1px] h-12 bg-white/30 mx-auto" />
      </motion.div>
    </section>
  );
}
